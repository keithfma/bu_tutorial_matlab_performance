tic
i = 0;
for t = 0:.01:100
    i = i + 1;
    y(i) = sin(t);
end
toc
