x = randn(5000);
tic
y = x.^2;
toc
