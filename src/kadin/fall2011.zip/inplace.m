x = randn(5000);
tic
x = x.^2;
toc
