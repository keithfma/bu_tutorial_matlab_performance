n = 5000;
tic
for i=1:n
    x(i) = i^2;
end
toc
