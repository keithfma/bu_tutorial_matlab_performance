n = 5000; x = (1:n);
x = x.^2;
tic
x = realsqrt(x);
toc

